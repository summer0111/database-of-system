//==========================================
//文 件 名：user.js
//文件用途：考生页面JS函数
//版权所有：方卡在线 http://www.fangka.net/
//==========================================

var answerQuestion=0;
var allQuestion=0;
var answerList=',';
var examTime=0;
var examTimeRun=1;
var timeBoxTop=0;

//加入页面保护
function rf() {
	return false;
}
document.oncontextmenu = rf

$(document).keydown(function(event){ 
	if(event.ctrlKey == true || event.keyCode == 93){
		return false;
	}
}); 

function drag() {
	return false;
}
document.ondragstart = drag
function stopmouse(e) {
	if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
	else if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) {
		alert("请认真考试！");
		return false;
	}
	return true;
}
document.onmousedown = stopmouse;
if (document.layers) window.captureEvents(Event.MOUSEDOWN);
window.onmousedown = stopmouse;

function JM_cc(ob) {
	var obj = MM_findObj(ob);
	if (obj) {
		obj.select();
		js = obj.createTextRange();
		js.execCommand("Copy");
	}
}

function MM_findObj(n, d) { //v4.0
	var p, i, x;
	if (!d) d = document;
	if ((p = n.indexOf("?")) > 0 && parent.frames.length) {
		d = parent.frames[n.substring(p + 1)].document;
		n = n.substring(0, p);
	}
	if (! (x = d[n]) && d.all) x = d.all[n];
	for (i = 0; ! x && i < d.forms.length; i++) x = d.forms[n];
	for (i = 0; ! x && d.layers && i < d.layers.length; i++) x = MM_findObj(n, d.layers.document);
	if (!x && document.getElementById) x = document.getElementById(n);
	return x;
}

function checkLeave(){
	if($('#TimeOut').val()==0)
		event.returnValue="考试尚未提交，请点击“取消”返回考试！”！";
}
window.getSelection ? window.getSelection().removeAllRanges() : document.selection.empty();

function scrollImg(){
	$('#timeBox').css('top',$(window).scrollTop()+100);
	setTimeout("scrollImg()",10);
}
function countTime(){
	if(examTime==0){   
		$('#TimeOut').val('1');
		document.getElementById("Enter").click();
	}   
	var startMinutes=parseInt(examTime/60,10);   
	var startSec=parseInt((examTime-startMinutes*60))   
	$('#countDown').html(startMinutes+'分钟'+startSec+'秒');   
	examTime=examTime-1;
	if(examTimeRun==1)
		setTimeout('countTime()',1000);   
}
function Res(Tis){
	if(answerList.indexOf(","+Tis+",")==-1){
		answerList=answerList+Tis+","
		answerQuestion=answerQuestion+1;
		$('#answerQuestions').html('答题：'+answerQuestion+'/'+allQuestion);
	}
}
function showDiv(boxId){
	$('#answerBox #answer').html($('#Box'+boxId).html());
	$('#answerBox').css('left',($(window).width()-500)/2);
	$('#answerBox').css('top',$(window).scrollTop()+($(window).height()-600)/2);
	$('#answerBox').show();
}




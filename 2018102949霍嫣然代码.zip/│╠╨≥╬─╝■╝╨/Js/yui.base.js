//==========================================
//文 件 名：yui.base.js
//文件用途：YUI基础函数
//版权所有：方卡在线 http://www.fangka.net/
//==========================================

//页面载入完毕宽度重设
$(document).ready(function(){
	pageReset();
});

//监听浏览器大小变化
//$(window).resize(function() {
//    pageReset();
//});

//监听按键
$(document).keydown(function(event){ 
	if(event.keyCode==27){
		dialogClose();
	}
}); 


//页面宽度重设
function pageReset(){
	var leftWidth=189;
	var rightWidth=$(window).width()-189;
	var documentHeight=$(document).height()-90;
	var leftHeight=$("#mainLeft").height();
	var rightHeight=$("#mainRight").height();
	if(rightWidth>812){
		$("#mainRight").width(rightWidth);
		$("#allbox").width($(window).width());
	}else{
		$("#mainRight").width(812);
		$("#allbox").width(1001);
	}
	if(leftHeight<documentHeight||leftHeight<rightHeight){
		if(rightHeight>documentHeight){
			$("#mainLeft").height(rightHeight);
		}else{
			$("#mainLeft").height(documentHeight);
		}
	}
	$("#dialogAlpha").height($(document).height());
	$("#dialogAlpha").width($(document).width());
}

//管理员页面初始化
function adminLoading(){
	ajax_get('userInfo','Get.asp?Type=1');
	ajax_get('nav','Get.asp?Type=2');
	ajax_get('mainLeft','Get.asp?Type=3');
	ajax_get('mainRight','Get.asp?Type=4');
}

//验证分值
function checknum(obj_input,maxnum){
	if(isNaN($(obj_input).val())){
		alert("分值必须是数字！");
		return false;
	}
	if($(obj_input).val()>maxnum){
		alert("本题最大分值为"+maxnum+"分！");
	}
}

(function($){ $.fn.simpletooltip = function(){
	return this.each(function() {
		var text = $(this).attr("title");
		$(this).attr("title", "");
		if(text != undefined) {
			$(this).hover(function(e){
				var tipX = e.pageX + 12;
				var tipY = e.pageY + 12;
				$(this).attr("title", ""); 
				$("body").append("<div id='simpleTooltip' style='position: absolute; z-index: 105; display: none;'>" + text + "</div>");
				if($.browser.msie) var tipWidth = $("#simpleTooltip").outerWidth(true)
				else var tipWidth = $("#simpleTooltip").width()
				$("#simpleTooltip").width(tipWidth);
				$("#simpleTooltip").css("left", tipX).css("top", tipY).fadeIn("medium");
			}, function(){
				$("#simpleTooltip").remove();
				$(this).attr("title", text);
			});
			$(this).mousemove(function(e){
				var tipX = e.pageX + 12;
				var tipY = e.pageY + 12;
				var tipWidth = $("#simpleTooltip").outerWidth(true);
				var tipHeight = $("#simpleTooltip").outerHeight(true);
				if(tipX + tipWidth > $(window).scrollLeft() + $(window).width()) tipX = e.pageX - tipWidth;
				if($(window).height()+$(window).scrollTop() < tipY + tipHeight) tipY = e.pageY - tipHeight;
				$("#simpleTooltip").css("left", tipX).css("top", tipY).fadeIn("medium");
			});
		}
	});
}})(jQuery);

